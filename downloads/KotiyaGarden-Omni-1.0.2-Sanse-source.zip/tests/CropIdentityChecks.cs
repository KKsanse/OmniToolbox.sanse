using GardenLayout;
using System.Text.Json;

static class CropIdentityChecks
{
 public static int Run()
 {
    int checks=0;void Check(bool ok,string name){if(!ok)throw new Exception(name);checks++;}
    var definitions=new[]{new GardenCropDefinition(7755,"黄麻种子",7774,"黄麻"),new GardenCropDefinition(7743,"风茄种子",5543,"风茄"),new GardenCropDefinition(13768,"库尔札斯茶树种子",12882,"库尔札斯茶叶"),new GardenCropDefinition(7723,"中原甘蓝种子",4789,"中原甘蓝"),new GardenCropDefinition(8182,"克拉卡萝卜种子",8165,"克拉卡萝卜")};
    foreach(string name in new[]{"风茄","库尔札斯茶叶","中原甘蓝","克拉卡萝卜"}){
        Check(GardenCropIdentity.ParseName(name+"正茁壮成长。")==name,"observed growth announcement extracts exact crop name");
        Check(GardenCropIdentity.Resolve(name,definitions)?.SeedId>0,"game crop item resolves to a unique seed");
    }
    Check(GardenCropIdentity.ParseName("作物正在健康成长。")==null,"generic care success is not a crop name");
    Check(GardenCropIdentity.ParseName("玩家说：风茄正茁壮成长。") is {} wrong&&GardenCropIdentity.Resolve(wrong,definitions)==null,"unmatched prefixed names never fill a record");
    Check(GardenCropIdentity.ParseName("风茄正茁壮成长。\n其他消息")==null,"multiline text rejected");
    Check(GardenCropIdentity.ParseName(new string('甲',129)+"正茁壮成长。")==null,"oversized announcement rejected");
    var now=new DateTimeOffset(2026,11,3,23,48,0,TimeSpan.FromHours(8));var target=new GardenTarget(50,9,7);var crop=GardenCropIdentity.Resolve("风茄",definitions)!;
    var pending=new GardenNameObservation(1,9,7,50,now,crop);
    Check(GardenCropIdentity.Matches(pending,1,target,"园圃1：地垄8",now.AddMilliseconds(100)),"current garden menu confirms slot identity");
    Check(!GardenCropIdentity.Matches(pending,2,target,"园圃1：地垄8",now),"same slot in another house rejected");
    Check(!GardenCropIdentity.Matches(pending,1,new(51,10,7),"园圃2：地垄8",now),"neighboring bed with same slot rejected");
    Check(!GardenCropIdentity.Matches(pending,1,target,"园圃1：地垄7",now),"previous menu for a different slot rejected");
    Check(!GardenCropIdentity.Matches(pending,1,target,"园圃1：地垄8",now.AddSeconds(3)),"stale announcement cannot fill a later target");
    Check(!GardenCropIdentity.Matches(pending,1,target,"园圃1：地垄8",now.AddSeconds(-1)),"future/cross-clock candidate rejected");
    var record=new GardenRecord{HouseId=1,GroupKey=9,NativeSlot=7,CaredAt=now.AddMinutes(-3),FertilizedAt=now.AddMinutes(-10),FertilizerReminderBase=now.AddMinutes(-10),FertilizerReminderSentAt=now.AddMinutes(-1)};
    Check(GardenCropIdentity.Apply(record,crop,now)&&record.SeedId==7743&&record.CropName=="风茄","unknown seed becomes known from exact observed crop");
    Check(record.PlantedAt==null&&record.CaredAt==now.AddMinutes(-3)&&record.FertilizedAt==now.AddMinutes(-10),"identification preserves known operation times and unknown planting time");
    Check(record.FertilizerReminderBase==now.AddMinutes(-10)&&record.FertilizerReminderSentAt==now.AddMinutes(-1),"identification never restarts reminder cycle");
    Check(!GardenCropIdentity.Apply(record,crop,now.AddSeconds(1))&&record.SeedIdentifiedAt==now,"duplicate announcement does not save/rewrite identification time");
    var shared=GardenCropIdentity.Resolve("黄麻",definitions.Append(new GardenCropDefinition(888,"其他黄麻种子",7774,"黄麻")))!;
    Check(shared.SeedId==0&&shared.CropItemId==7774,"ambiguous seed mapping retains crop without guessing seed");
    var unknown=new GardenRecord();GardenCropIdentity.Apply(unknown,shared,now);Check(unknown.SeedId==0&&unknown.CropName=="黄麻","known crop can be shown while seed remains unconfirmed");
    var loaded=JsonSerializer.Deserialize<GardenRecord>(JsonSerializer.Serialize(record))!;
    Check(loaded.SeedId==7743&&loaded.CropName=="风茄"&&loaded.SeedIdentifiedAt==now&&loaded.CaredAt==record.CaredAt,"identity and existing timestamps persist together");
    GardenLedger.Record(record,GardenAction.Plant,now.AddMinutes(1),7755);Check(record.CropName==""&&record.CropItemId==0&&record.SeedIdentifiedAt==null&&record.SeedId==7755,"new planting clears the prior crop identification");
    GardenCropObservation.Apply(record,GardenCropState.Empty,now.AddMinutes(2));GardenCropIdentity.Apply(record,crop,now.AddMinutes(3));Check(record.PlantedAt==null&&record.CaredAt==null&&record.SeedId==7743,"new unobserved crop does not inherit archived cycle times");
    return checks;
 }
}

