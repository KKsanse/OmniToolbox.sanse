using GardenLayout;
using FFXIVClientStructs.FFXIV.Client.Game;
using FFXIVClientStructs.FFXIV.Component.GUI;

unsafe class NativeMenuChecks
{
 static void Main()
 {
    int checks=0;void Check(bool condition,string name){if(!condition)throw new Exception(name);checks++;}
    var items=stackalloc AtkComponentList.ListItem[4];
    for(int i=0;i<4;i++)items[i]=new(){IsDisabled=i==0};
    var list=new AtkComponentList{ListLength=4,AllocatedItemRendererListLength=4,ItemRendererList=items};
    Check(GardenNativeMenu.TrySnapshot(list,4,out var enabled)&&enabled.SequenceEqual(new[]{false,true,true,true}),"actual SDK disabled rows copied correctly");
    items[0].IsDisabled=false;Check(!enabled[0],"snapshot cannot change with later native row updates");
    list.IsUpdatePending=true;Check(!GardenNativeMenu.TrySnapshot(list,4,out _),"pending layout never used");list.IsUpdatePending=false;
    list.AllocatedItemRendererListLength=3;Check(!GardenNativeMenu.TrySnapshot(list,4,out _),"short allocation rejected before reading");
    list.AllocatedItemRendererListLength=4;Check(!GardenNativeMenu.TrySnapshot(list,6,out _),"menu count mismatch rejected");
    list.ItemRendererList=null;Check(!GardenNativeMenu.TrySnapshot(list,4,out _),"null native rows rejected");
    Check(!GardenNativeMenu.TrySnapshot(list,0,out _)&&!GardenNativeMenu.TrySnapshot(list,17,out _),"unbounded counts rejected");
    byte[] titleBytes=System.Text.Encoding.UTF8.GetBytes("园圃2：地垄8\0");
    fixed(byte* titlePointer=titleBytes){
        AtkTextNode node=default;node.NodeId=2;node.Type=NodeType.Text;node.NodeText.StringPtr=titlePointer;node.NodeText.BufSize=titleBytes.Length;node.NodeText.BufUsed=titleBytes.Length;
        Check(GardenNativeMenu.TryReadTitle(node,out var title)&&title=="园圃2：地垄8","actual SDK UTF8 title decoded with explicit bounded size");
        node.NodeId=3;Check(!GardenNativeMenu.TryReadTitle(node,out _),"wrong title node rejected");node.NodeId=2;
        node.NodeText.BufUsed=513;Check(!GardenNativeMenu.TryReadTitle(node,out _),"oversized native title rejected before access");
        node.NodeText.BufUsed=titleBytes.Length;node.NodeText.BufSize=1;Check(!GardenNativeMenu.TryReadTitle(node,out _),"clamped native string cannot be read as longer buffer");
        node.NodeText.StringPtr=(byte*)0;Check(!GardenNativeMenu.TryReadTitle(node,out _),"null native string rejected");
    }
    Check(GardenFertilizer.Resolve(0)==7767,"unset legacy configuration defaults to fishmeal");
    Check(GardenFertilizer.Resolve(7767)==7767&&GardenFertilizer.Resolve(12345)==12345,"explicit fertilizer choices preserved");
    var inventory=stackalloc InventoryItem[140];var containers=stackalloc InventoryContainer[4];Span<nint> bags=stackalloc nint[4];
    for(int i=0;i<4;i++){containers[i]=new(){Items=inventory+i*35,Type=(InventoryType)i,Size=35,IsLoaded=true};bags[i]=(nint)(containers+i);}
    inventory[90]=new(){Container=InventoryType.Inventory3,Slot=20,ItemId=7767,Quantity=737};
    Check(GardenNativeInventory.FindInBags(bags,7767,out var fish)==GardenStockStatus.Available&&fish.Container==InventoryType.Inventory3&&fish.Slot==20&&fish.Quantity==737,"fishmeal in third carried bag selected using actual SDK layout");
    containers[0].IsLoaded=false;
    Check(GardenNativeInventory.FindInBags(bags,7767,out _)==GardenStockStatus.Available,"unavailable earlier bag does not hide later fishmeal");
    Check(GardenNativeInventory.FindInBags(bags,9999,out _)==GardenStockStatus.Unavailable,"incomplete inventory is not reported as empty");containers[0].IsLoaded=true;
    Check(GardenNativeInventory.FindInBags(bags,9999,out _)==GardenStockStatus.Missing,"missing custom fertilizer does not use fishmeal silently");
    inventory[90].Quantity=0;Check(GardenNativeInventory.FindInBags(bags,7767,out _)==GardenStockStatus.Missing,"consumed stack never selected");inventory[90].Quantity=737;
    inventory[90].IsSymbolic=true;Check(GardenNativeInventory.FindInBags(bags,7767,out _)==GardenStockStatus.Missing,"symbolic inventory links not treated as physical fertilizer");inventory[90].IsSymbolic=false;
    inventory[90].Slot=19;Check(GardenNativeInventory.FindInBags(bags,7767,out _)==GardenStockStatus.Missing,"wrong physical slot rejected");inventory[90].Slot=20;
    containers[2].Size=36;Check(GardenNativeInventory.FindInBags(bags,7767,out _)==GardenStockStatus.Unavailable,"oversized container rejected before traversal");containers[2].Size=35;
    containers[2].Items=null;Check(GardenNativeInventory.FindInBags(bags,7767,out _)==GardenStockStatus.Unavailable,"null slot buffer rejected");
    Check(GardenNativeInventory.FindInBags(bags[..3],7767,out _)==GardenStockStatus.Unavailable,"bounded four-bag input required");
    Console.WriteLine($"PASS: {checks} native SDK menu snapshot checks. No game process access.");
 }
}

