using GardenLayout;
using System.Text.Json;
static class AddressNameChecks
{
 public static int Run(){
  int n=0;void Check(bool ok,string label){if(!ok)throw new Exception(label);n++;}
  void Reject(Action action,string label){try{action();}catch(ArgumentException){n++;return;}throw new Exception(label);}
  ulong id=((ulong)99<<48)|((ulong)340<<32)|((ulong)11<<16)|34;
  var address=GardenAddress.Decode(id)!;
  Check(address.WorldId==99&&address.TerritoryTypeId==340&&address.Ward==12&&address.Plot==35,"saved address follows HouseId field contract");
  Check(address.Describe("示例服","海雾村").Contains("海雾村 12区35号"),"name suffix contains district, ward and plot");
  Check(GardenAddress.Decode(0)==null&&GardenAddress.Decode(1)==null,"unknown old identities do not fabricate addresses");
  Check(GardenAddress.Decode(((ulong)1<<48)|((ulong)341<<32)|0x80)!.Plot==null,"apartment flag not treated as plot number");
  var other=GardenAddress.Decode(id+((ulong)1<<48))!;Check(other.WorldId==100&&other.Ward==12,"same ward on different worlds stays distinguishable");
  Check(GardenAddress.Decode(((ulong)1<<48)|((ulong)340<<32))!.Plot==1,"zero based plot displayed as one based");
  var names=new Dictionary<string,string>();GardenNames.Set(names,1,10," 主屋杂交田 ");GardenNames.Set(names,2,10,"共享屋试验田");
  Check(names[GardenNames.Key(1,10)]=="主屋杂交田"&&names[GardenNames.Key(2,10)]=="共享屋试验田","rename isolated by house and garden, including unbound gardens");
  var restored=JsonSerializer.Deserialize<Dictionary<string,string>>(JsonSerializer.Serialize(names))!;Check(restored["1:10"]=="主屋杂交田","garden name persists");
  Reject(()=>GardenNames.Set(names,1,10,"  "),"empty name rejected");
  Reject(()=>GardenNames.Set(names,1,10,new string('田',41)),"overlong name rejected");
  Reject(()=>GardenNames.Set(names,1,10,"田\n地"),"multiline name rejected");
  Reject(()=>GardenNames.Set(names,1,10,"田##id"),"hidden label marker rejected");
  Check(names["1:10"]=="主屋杂交田","invalid rename does not erase saved name");
  Check(GardenNames.TryParseKey("2:10",out var house,out var group)&&house==2&&group==10,"saved unbound garden key restores its house scope");
  Check(!GardenNames.TryParseKey("0:10",out _,out _)&&!GardenNames.TryParseKey("broken",out _,out _),"malformed saved garden keys are ignored");
  return n;
 }
}
