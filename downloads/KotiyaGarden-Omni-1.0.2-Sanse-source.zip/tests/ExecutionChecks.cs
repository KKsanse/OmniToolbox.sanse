using GardenLayout;

static class ExecutionChecks
{
    // Models the installed TaskHelper contract: higher-weight pending tasks may
    // run next but never preempt the current task while its poll returns false.
    sealed class QueueModel
    {
        readonly SortedDictionary<int,Queue<Func<bool>>> pending=new(Comparer<int>.Create((a,b)=>b.CompareTo(a)));
        Func<bool>? current;
        public bool Busy=>current!=null||pending.Values.Any(q=>q.Count>0);
        public int Frame;
        public void Add(Func<bool> task,string name="",int priority=0){if(!pending.TryGetValue(priority,out var q))pending[priority]=q=new();q.Enqueue(task);}
        public void Abort(){pending.Clear();current=null;}
        public void Tick(){Frame++;current??=pending.Values.FirstOrDefault(q=>q.Count>0)?.Dequeue();if(current?.Invoke()==true)current=null;}
        public void Run(int max=100){for(int i=0;i<max&&Busy;i++)Tick();}
    }
    public static int Run()
    {
        int checks=0;
        void Check(bool ok,string name){if(!ok)throw new Exception(name);checks++;}
        var old=new QueueModel();bool oldFilled=false;
        old.Add(()=>oldFilled,"wait for result");old.Tick();
        old.Add(()=>{oldFilled=true;return true;},"addon fill",2);old.Run(40);
        Check(old.Busy&&!oldFilled,"reproduces original stall: a queued addon fill cannot preempt result wait");

        var q=new QueueModel();bool begun=false,selected=false,filled=false,confirmed=false,finished=false;
        int fills=0,confirms=0;
        GardenPlantSequence.Enqueue((poll,name)=>q.Add(poll,name),
            ()=>{begun=true;return true;},
            ()=>{if(q.Frame<5)return false;selected=begun;return selected;},
            ()=>{if(!selected||q.Frame<8)return false;filled=true;fills++;return true;},
            ()=>{if(!filled||q.Frame<12)return false;confirmed=true;confirms++;return true;},
            ()=>{if(!confirmed||q.Frame<18)return false;finished=true;return true;});
        q.Run();
        Check(finished&&!q.Busy,"new sequence completes with delayed window, confirmation and inventory updates");
        Check(fills==1&&confirms==1&&q.Frame>=18,"material submission and confirmation happen once");

        q=new();int writes=0;bool occupied=false;
        GardenPlantSequence.Enqueue((poll,name)=>q.Add(poll,name),()=>true,()=>{occupied=true;return true;},
            ()=>{if(!occupied)writes++;return true;},()=>{if(!occupied)writes++;return true;},()=>true);
        q.Run();Check(writes==0&&!q.Busy,"skipping existing crop does not fill materials or click confirmation");

        q=new();bool ready=false;int afterStop=0;
        GardenPlantSequence.Enqueue((poll,name)=>q.Add(poll,name),()=>true,()=>true,()=>ready,
            ()=>{afterStop++;return true;},()=>true);
        for(int i=0;i<10;i++)q.Tick();q.Abort();ready=true;q.Run();
        Check(afterStop==0&&!q.Busy,"cancellation while waiting for window prevents later confirmation");

        q=new();int nextPlot=0;
        GardenPlantSequence.Enqueue((poll,name)=>q.Add(poll,name),()=>true,()=>true,()=>false,()=>true,()=>true);
        q.Add(()=>{nextPlot++;return true;});q.Run(20);q.Abort();q.Run();
        Check(nextPlot==0,"a stalled or timed-out plot cannot advance to the next plot");

        var clipboard=new GardenSeedClipboard();
        var source=new GardenCell{NativeSlot=4,SeedId=17,SoilId=9};
        var destination=new GardenCell{NativeSlot=1,SeedId=18,SoilId=10};
        Check(!clipboard.Paste(destination)&&destination.SeedId==18,"paste before copy does not clear existing seed");
        Check(clipboard.Copy(source)&&clipboard.Paste(destination)&&destination.SeedId==17,"copy seed into another plot");
        Check(destination.NativeSlot==1&&destination.SoilId==10,"copying seed retains destination soil and slot calibration");
        source.SeedId=33;Check(clipboard.SeedId==17,"copied seed is a snapshot, not a reference to source cell");
        Check(!clipboard.Copy(new())&&clipboard.SeedId==17,"empty source does not erase clipboard");
        var first=GardenPlanner.Create(8);first.Cells[0].SeedId=17;first.Cells[1].SeedId=17;
        var second=GardenPlanner.Create(8);second.Cells[2].SeedId=18;
        Check(GardenSeedClipboard.ConfiguredSeeds(new[]{first,second}).SequenceEqual(new uint[]{17,18}),"reuse list spans layouts, excludes empty seeds, and deduplicates");
        first.Cells[0].SeedId=44;Check(GardenSeedClipboard.ConfiguredSeeds(new[]{first,second}).Contains(44),"reuse list reflects edits");
        var restored=System.Text.Json.JsonSerializer.Deserialize<GardenPreset>(System.Text.Json.JsonSerializer.Serialize(first))!;
        Check(restored.Cells[0].SeedId==44,"edited seed survives layout serialization");
        return checks;
    }
}
