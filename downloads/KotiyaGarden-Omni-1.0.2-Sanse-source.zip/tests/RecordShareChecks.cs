using GardenLayout;
using System.Text;
using System.Text.Json;

static class RecordShareChecks
{
 public static int Run()
 {
    int checks=0;void Check(bool ok,string name){if(!ok)throw new Exception(name);checks++;}
    void Reject(Action action,string name){try{action();}catch(ArgumentException){checks++;return;}throw new Exception(name);}
    var now=new DateTimeOffset(2026,11,3,0,41,0,TimeSpan.FromHours(8));
    var records=new List<GardenRecord>();var binding=new GardenBinding{HouseId=1,GroupKey=0x2202,LayoutId="test"};
    for(int i=0;i<8;i++){
        var signal=GardenLedger.ParseSuccess($"在园圃1的第{i+1}个地垄上播下了种子。");
        Check(signal?.Action==GardenAction.Plant&&signal.NativeSlot==i&&signal.GardenNumber==1,"observed eight-slot success message grammar");
        var record=GardenLedger.GetOrCreate(records,1,0x2202,i);GardenLedger.Record(record,GardenAction.Plant,now.AddSeconds(i),(uint)(i%2+1));
    }
    Check(records.Count==8&&records.Select(r=>r.NativeSlot).Distinct().Count()==8,"one record per slot");
    Check(GardenLedger.ParseSuccess("给作物施加了肥料。")?.Action==GardenAction.Fertilize&&GardenLedger.ParseSuccess("作物正在健康成长。")?.Action==GardenAction.Care,"observed separate fertilizer/care confirmations");
    Check(GardenLedger.ParseSuccess("无法播种，土壤里已经种有作物了。") is null&&GardenLedger.ParseSuccess("种植任务开始") is null,"requests and errors are not successes");
    Check(GardenLedger.ParseSuccess("在园圃1的第0个地垄上播下了种子。") is null&&GardenLedger.ParseSuccess("在园圃1的第9个地垄上播下了种子。") is null,"invalid game slot numbers rejected");
    Check(GardenLedger.Pending(records,new[]{binding},now.AddMinutes(59)).Count==0,"reminders not early");
    var due=GardenLedger.Pending(records,new[]{binding},now.AddMinutes(61));
    Check(due.Count==8&&due.All(d=>d.Action==GardenAction.Fertilize),"first fertilizer reminder uses planted time");
    due.ForEach(d=>GardenLedger.MarkSent(d,now.AddMinutes(61)));
    Check(GardenLedger.Pending(records,new[]{binding},now.AddMinutes(80)).Count==0,"single reminders do not repeat every poll");
    var savedRecords=JsonSerializer.Deserialize<List<GardenRecord>>(JsonSerializer.Serialize(records))!;
    Check(GardenLedger.Pending(savedRecords,new[]{binding},now.AddMinutes(80)).Count==0,"dedup survives reload");
    binding.Reminders.RepeatMinutes=30;
    Check(GardenLedger.Pending(records,new[]{binding},now.AddMinutes(90)).Count==0&&GardenLedger.Pending(records,new[]{binding},now.AddMinutes(92)).Count==8,"repeat interval respected");
    binding.Reminders.RepeatMinutes=0;
    foreach(var record in records){GardenLedger.Record(record,GardenAction.Fertilize,now.AddMinutes(100));GardenLedger.Record(record,GardenAction.Care,now.AddMinutes(10));}
    Check(GardenLedger.Pending(records,new[]{binding},now.AddMinutes(159)).Count==0,"successful fertilizer operation restarts its timer");
    Check(GardenLedger.Pending(records,new[]{binding},now.AddMinutes(161)).Count==8,"new fertilizer cycle gets new reminder");
    binding.Reminders.FertilizerEnabled=false;
    Check(GardenLedger.Pending(records,new[]{binding},now.AddMinutes(729)).Count==0,"care interval based on latest care, fertilizer disabled");
    Check(GardenLedger.Pending(records,new[]{binding},now.AddMinutes(731)).Count==8,"care due per slot");
    binding.Reminders.CareEnabled=false;Check(GardenLedger.Pending(records,new[]{binding},now.AddDays(3)).Count==0,"both reminder kinds can be disabled");
    binding.Reminders.CareEnabled=true;binding.Reminders.FertilizerEnabled=true;
    GardenLedger.Record(records[0],GardenAction.Harvest,now.AddMinutes(20));
    Check(!records[0].Active&&GardenLedger.DueAt(records[0],binding.Reminders,GardenAction.Care)==null,"harvested crop excluded from reminders");
    GardenLedger.Record(records[0],GardenAction.Plant,now.AddMinutes(21),9);
    Check(records[0].Active&&records[0].SeedId==9&&records[0].CaredAt==null&&records[0].FertilizedAt==null&&records[0].CareReminderSentAt==null,"new crop resets old operation times and reminder dedup");
    Check(!GardenLedger.Record(records[0],GardenAction.Care,now.AddMinutes(20)),"late old-crop feedback is ignored");
    Check(!GardenLedger.Record(records[0],GardenAction.Plant,now.AddMinutes(21),8)&&records[0].SeedId==9,"same-time duplicate feedback cannot overwrite crop");
    var unknown=GardenLedger.GetOrCreate(records,1,0x2202,7);unknown.PlantedAt=unknown.CaredAt=unknown.FertilizedAt=null;
    Check(GardenLedger.DueAt(unknown,binding.Reminders,GardenAction.Care)==null,"unknown historical time stays unknown");
    Check(GardenLedger.Pending(records,new[]{new GardenBinding{HouseId=2,GroupKey=0x2202}},now.AddDays(5)).Count==0,"same group in another house never gets this house's reminder");
    Check(GardenLedger.Pending(records,Array.Empty<GardenBinding>(),now.AddDays(5)).Count==0,"deleted binding produces no reminders");
    var guard=new GardenRunGuard();var target=new GardenTarget(100,0x2202,0);
    Check(guard.Begin(1,target,GardenAction.Plant)&&!guard.Begin(1,target,GardenAction.Plant),"same run does not interact with a planting slot twice");
    Check(guard.Begin(1,target,GardenAction.Care)&&guard.Begin(1,target,GardenAction.Fertilize),"explicit care and fertilizer runs remain separate actions");
    Check(guard.Complete(1,target,GardenAction.Plant)&&!guard.Complete(1,target,GardenAction.Plant),"duplicate success callback recorded once");
    guard.Clear();Check(guard.Begin(1,target,GardenAction.Plant),"new user-started run is independent");
    var preset=new GardenPreset{Name="杂交布局",DefaultSoilId=9,Cells=Enumerable.Range(0,8).Select(i=>new GardenCell{NativeSlot=i,SeedId=(uint)(i%2+1),SoilId=i==0?10u:0}).ToList(),PlantOrder=new(){7,6,5,4,3,2,1,0}};
    (preset.Cells[0].NativeSlot,preset.Cells[7].NativeSlot)=(7,0);
    var seeds=new HashSet<uint>{1,2};var soils=new HashSet<uint>{9,10};
    string code=GardenShare.Export(preset);var imported=GardenShare.Import(code,new[]{preset},seeds,soils);
    Check(code.StartsWith("GLW1:")&&imported.Id!=preset.Id&&imported.Name!=preset.Name,"share import creates new identity and unique name");
    Check(imported.Cells[0].NativeSlot==7&&imported.Cells[0].SoilId==10&&imported.PlantOrder.SequenceEqual(preset.PlantOrder)&&imported.Cells[1].SeedId==2,"share retains seeds, soil overrides, mapping and planting order");
    imported.Cells[0].SeedId=2;Check(preset.Cells[0].SeedId==1,"imported layout does not alias original objects");
    string json=Encoding.UTF8.GetString(Convert.FromBase64String(code[5..]));
    Check(!json.Contains("HouseId")&&!json.Contains("GroupKey")&&!json.Contains("PlantedAt")&&!json.Contains("Records")&&!json.Contains("LayoutId")&&!json.Contains("\"Id\""),"export allowlist excludes garden bindings, house identity, operation times and internal id");
    Reject(()=>GardenShare.Import("https://example.com",[],seeds,soils),"links are not executed or fetched");
    Reject(()=>GardenShare.Import("GLW1:broken",[],seeds,soils),"malformed base64 rejected");
    Reject(()=>GardenShare.Import("GLW1:"+new string('A',GardenShare.MaxCodeLength),[],seeds,soils),"oversized share code rejected");
    string Encode(string text)=>"GLW1:"+Convert.ToBase64String(Encoding.UTF8.GetBytes(text));
    Reject(()=>GardenShare.Import(Encode(json.Replace("\"Version\":1","\"Version\":2")),[],seeds,soils),"unsupported share version rejected");
    Reject(()=>GardenShare.Import(code,[],new HashSet<uint>{1},soils),"unavailable seeds rejected before import");
    Reject(()=>GardenShare.Import(code,[],seeds,new HashSet<uint>{9}),"unavailable soil override rejected before import");
    preset.Cells[1].NativeSlot=preset.Cells[0].NativeSlot;Reject(()=>GardenShare.Export(preset),"invalid mapping cannot be exported");
    var roundtrip=JsonSerializer.Deserialize<GardenBinding>(JsonSerializer.Serialize(binding))!;
    Check(roundtrip.Reminders.CareMinutes==720&&roundtrip.Reminders.FertilizerMinutes==60,"per-garden reminder settings persist");
    var legacy=JsonSerializer.Deserialize<GardenBinding>("{\"HouseId\":1,\"GroupKey\":8706,\"LayoutId\":\"old\"}")!;
    Check(legacy.Reminders!=null&&legacy.Reminders.CareEnabled,"old binding data loads with new defaults");
    var harvested=new GardenRecord{SeedId=1,PlantedAt=now,FertilizedAt=now.AddMinutes(1)};
    GardenLedger.Record(harvested,GardenAction.Harvest,now.AddMinutes(2));GardenLedger.Record(harvested,GardenAction.Care,now.AddMinutes(3));
    Check(harvested.Active&&harvested.SeedId==0&&harvested.PlantedAt==null&&harvested.FertilizedAt==null&&harvested.CaredAt==now.AddMinutes(3),"care of a new unobserved crop does not inherit prior harvested crop times");
    return checks;
 }
}
