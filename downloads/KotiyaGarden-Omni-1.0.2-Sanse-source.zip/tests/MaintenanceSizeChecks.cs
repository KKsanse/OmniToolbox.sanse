using GardenLayout;
using System.Text.Json;

static class MaintenanceSizeChecks
{
 public static int Run()
 {
    int checks=0;void Check(bool ok,string name){if(!ok)throw new Exception(name);checks++;}
    void Reject(Action action,string name){try{action();}catch(ArgumentException){checks++;return;}throw new Exception(name);}
    var yes=new GardenMenuOption(true,true);var no=new GardenMenuOption(false,null);var disabled=new GardenMenuOption(true,false);
    var empty=new GardenMenuState(yes,no,no,no);var growing=new GardenMenuState(no,yes,yes,no);var cooldown=new GardenMenuState(no,yes,disabled,no);var mature=new GardenMenuState(no,no,no,yes);
    Check(empty.Crop==GardenCropState.Empty&&empty.SkipReason(GardenAction.Care)!=null&&empty.SkipReason(GardenAction.Fertilize)!=null,"empty soil never cared or fertilized");
    Check(growing.Crop==GardenCropState.Growing&&growing.SkipReason(GardenAction.Care)==null&&growing.SkipReason(GardenAction.Fertilize)==null,"growing available actions execute");
    Check(cooldown.Crop==GardenCropState.Growing&&cooldown.SkipReason(GardenAction.Fertilize)!=null&&cooldown.SkipReason(GardenAction.Care)==null,"disabled fertilizer cannot block usable care");
    Check(mature.Crop==GardenCropState.Ready&&mature.SkipReason(GardenAction.Care)!=null&&mature.SkipReason(GardenAction.Fertilize)!=null&&mature.SkipReason(GardenAction.Harvest)==null,"mature crop maintained by harvest only");
    Check(new GardenMenuState(no,new(true,null),no,no).SkipReason(GardenAction.Care)!=null,"unknown enable state fails closed");
    Check(new GardenMenuState(no,yes,yes,disabled).Crop==GardenCropState.Growing,"disabled harvest entry does not mark immature crop ripe");
    Check(GardenMaintenanceFailure.Parse("已经施加了足够的肥料了。",GardenAction.Fertilize)!=null&&GardenMaintenanceFailure.Parse("已经施加了足够的肥料了。",GardenAction.Care)==null,"cooldown denial belongs to fertilizer only");
    Check(GardenMaintenanceFailure.Parse("给作物施加了肥料。",GardenAction.Fertilize)==null,"fertilizer success is not rejection");
    var now=new DateTimeOffset(2026,11,3,22,0,0,TimeSpan.FromHours(8));var binding=new GardenBinding{HouseId=1,GroupKey=1};binding.Reminders.CareEnabled=false;
    var rows=Enumerable.Range(0,4).Select(i=>new GardenRecord{HouseId=1,GroupKey=1,NativeSlot=i,SeedId=9,PlantedAt=now.AddMinutes(-65+i*2),ObservedState=GardenCropState.Growing}).ToList();
    Check(GardenLedger.Pending(rows,[binding],now).Count==0,"3 of 4 due cannot notify whole garden");
    var due=GardenLedger.Pending(rows,[binding],now.AddMinutes(1));Check(due.Count==4,"all due at exact final boundary form one batch");
    due.ForEach(d=>GardenLedger.MarkSent(d,now.AddMinutes(1)));Check(GardenLedger.Pending(rows,[binding],now.AddMinutes(10)).Count==0,"batch does not notify each remaining slot later");
    binding.Reminders.RepeatMinutes=20;Check(GardenLedger.Pending(rows,[binding],now.AddMinutes(20)).Count==0&&GardenLedger.Pending(rows,[binding],now.AddMinutes(21)).Count==4,"repeat applies to the whole batch");
    GardenLedger.Record(rows[0],GardenAction.Fertilize,now.AddMinutes(30));Check(GardenLedger.Pending(rows,[binding],now.AddMinutes(80)).Count==0,"partial fertilizer run postpones next whole-bed notification");
    rows[0].PlantedAt=rows[0].FertilizedAt=null;Check(GardenLedger.Pending(rows,[binding],now.AddDays(1)).Count==0,"active crop with unknown time blocks false whole-bed claim");
    GardenCropObservation.Apply(rows[0],GardenCropState.Empty,now.AddMinutes(31));
    Check(!rows[0].Active&&rows[0].HarvestedAt==null&&GardenLedger.Pending(rows,[binding],now.AddDays(1)).Count==3,"empty soil excluded without invented harvest time");
    GardenCropObservation.Apply(rows[1],GardenCropState.Ready,now.AddMinutes(31));Check(GardenLedger.Pending(rows,[binding],now.AddDays(1)).Count==2,"detected mature crop excluded from maintenance deadlines");
    GardenCropObservation.Apply(rows[0],GardenCropState.Growing,now.AddMinutes(32));Check(rows[0].Active&&rows[0].SeedId==0&&rows[0].PlantedAt==null,"new unobserved crop never inherits prior seed or time");
    Check(GardenLedger.ReminderText("试验田","示例房区",GardenAction.Fertilize,4).Contains("4 株")&&GardenLedger.ReminderText("试验田","示例房区",GardenAction.Fertilize,4).Contains("均已到"),"notification says whole recorded garden is due");
    Check(GardenPlanner.FurnitureSlots(131126)==4&&GardenPlanner.FurnitureSlots(131127)==6&&GardenPlanner.FurnitureSlots(131128)==8&&GardenPlanner.FurnitureSlots(1)==0,"three verified furnishing identities mapped");
    foreach(int count in new[]{4,6,8}){
        var preset=GardenPlanner.Create(count);preset.DefaultSoilId=10;preset.Cells.ForEach(c=>c.SeedId=9);
        var targets=Enumerable.Range(0,count).Select(i=>GardenPlanner.Decode((ulong)(100+i),2003757,((uint)i<<24)|1)).ToList();
        var plan=GardenPlanner.Plan(preset,targets,1,false);Check(plan.Count==count&&plan.Select(p=>p.NativeSlot).SequenceEqual(Enumerable.Range(0,count)),"planning covers exact size "+count);
        Check(GardenPlanner.Grid(count).Where(i=>i>=0).Order().SequenceEqual(Enumerable.Range(0,count)),"grid renders every size slot exactly once "+count);
        var imported=GardenShare.Import(GardenShare.Export(preset),[preset],new HashSet<uint>{9},new HashSet<uint>{10});Check(imported.Cells.Count==count&&imported.PlantOrder.Count==count,"sharing retains size and order "+count);
        Reject(()=>GardenPlanner.Plan(preset,targets.Take(count-1).ToList(),1,false),"partial loaded bed rejected "+count);
    }
    var sparse=GardenPlanner.Create(4,[0,2,4,6]);Check(sparse.Cells.Select(c=>c.NativeSlot).SequenceEqual(new[]{0,2,4,6}),"factory retains actual game slot indices");
    Reject(()=>GardenPlanner.Create(6,[0,1,2,3]),"cannot silently truncate a six-cell garden");Reject(()=>GardenPlanner.Create(5),"invalid garden size rejected");
    var persisted=JsonSerializer.Deserialize<GardenRecord>(JsonSerializer.Serialize(rows[1]))!;Check(persisted.ObservedState==GardenCropState.Ready&&persisted.ObservedAt.HasValue,"observed state and time survive reload");
    return checks;
 }
}
