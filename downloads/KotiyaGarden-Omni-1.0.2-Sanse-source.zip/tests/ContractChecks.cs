using System.Reflection;
using System.Runtime.Loader;
using System.Collections;

class ContractChecks
{
 static void Main(string[] args)
 {
    var moduleFile=Path.GetFullPath(args[0]);var roots=args.Skip(1).Select(Path.GetFullPath).ToList();roots.Insert(0,Path.GetDirectoryName(moduleFile)!);
    AssemblyLoadContext.Default.Resolving+=(_,name)=>{
        foreach(var root in roots){string file=Path.Combine(root,name.Name+".dll");if(File.Exists(file))return AssemblyLoadContext.Default.LoadFromAssemblyPath(file);}return null;
    };
    int checks=0;void Check(bool condition,string name){if(!condition)throw new Exception(name);checks++;}
    var assembly=AssemblyLoadContext.Default.LoadFromAssemblyPath(moduleFile);
    var type=assembly.GetType("OmniToolbox.TreeHouseLocal.KotiyaGarden",true)!;
    Check(type.BaseType?.FullName=="OmniToolbox.Common.Module.Abstractions.OmniModuleBase","current Omni base contract");
    Check(type.GetCustomAttributes().Any(a=>a.GetType().Name=="ModuleApiVersionAttribute"&&(int)a.GetType().GetProperty("Version")!.GetValue(a)! ==1),"API version one declared");
    Check(type.GetConstructor(Type.EmptyTypes)!=null,"public parameterless constructor");
    Check(!assembly.GetReferencedAssemblies().Any(a=>a.Name!.StartsWith("DailyRoutines")),"no Daily Routines dependency");
    Check(assembly.GetTypes().Count(t=>!t.IsAbstract&&IsModule(t))==1,"one loadable Omni module per file");
    bool IsModule(Type t){for(var b=t.BaseType;b!=null;b=b.BaseType)if(b.FullName=="OmniToolbox.Common.Module.Abstractions.OmniModuleBase")return true;return false;}
    var instance=Activator.CreateInstance(type)!;
    var info=type.GetProperty("Info")!.GetValue(instance)!;
    Check((string)info.GetType().GetProperty("Author")!.GetValue(info)! =="Sanse","module author Sanse");
    var localization=type.GetProperty("Localization")!.GetValue(instance)!;
    var catalogs=(IEnumerable)localization.GetType().GetProperty("Catalogs")!.GetValue(localization)!;
    int languages=0;
    foreach(var pair in catalogs){
        string language=pair.GetType().GetProperty("Key")!.GetValue(pair)!.ToString()!;
        var texts=(IEnumerable)pair.GetType().GetProperty("Value")!.GetValue(pair)!;int count=0;
        foreach(var text in texts){Check(!string.IsNullOrWhiteSpace((string)text.GetType().GetProperty("Value")!.GetValue(text)!),"localized text cannot be blank");count++;}
        Console.WriteLine($"Catalog: {language}, {count} entries");
        if(language is "SimplifiedChinese" or "TraditionalChinese"){Check(count>=260,"all source keys translated in generated Chinese catalog");languages++;}
        else Check(count==0,"unfinished language is not silently filled with Chinese");
    }
    Check(languages==2,"host generates both Simplified and Traditional Chinese");
    var configField=type.GetField("config",BindingFlags.Instance|BindingFlags.NonPublic)!;
    Check(configField.FieldType.Name=="Settings","host settings binding follows current contract");
    var settingsField=type.GetField("config",BindingFlags.Instance|BindingFlags.NonPublic)!;
    var settings=settingsField.GetValue(instance)!;var fertilizer=settings.GetType().GetField("FertilizerSelected")!;
    Check((uint)fertilizer.GetValue(settings)! ==7767,"new Settings defaults to fishmeal");
    // Constructor and metadata inspection must not start any game service or create storage.
    Check(type.GetField("TaskHelper",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(instance)==null,"constructor starts no game task");
    var dir=Path.Combine(Path.GetDirectoryName(moduleFile)!,"contract-state-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(dir);var state=Path.Combine(dir,"state.json");
    type.GetField("stateFile",BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(instance,state);
    var persist=type.GetMethod("PersistState",BindingFlags.Instance|BindingFlags.NonPublic)!;persist.Invoke(instance,null);
    Check(!File.Exists(state),"failed/uninitialized startup cannot overwrite state");
    type.GetField("stateReady",BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(instance,true);persist.Invoke(instance,null);
    if(!File.Exists(state))Console.WriteLine(type.GetField("layoutNotice",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(instance));
    Check(File.Exists(state)&&File.ReadAllText(state).Contains("GardenBindings"),"state saves without settings page being visible");
    persist.Invoke(instance,null);Check(File.Exists(state+".bak"),"previous state preserved as backup");
    foreach(var input in new[]{"{}","{\"FertilizerSelected\":0}","{\"FertilizerSelected\":12345}"}){
        File.WriteAllText(state,input);type.GetMethod("LoadState",BindingFlags.Instance|BindingFlags.NonPublic)!.Invoke(instance,null);
        Check((uint)fertilizer.GetValue(settings)! ==(input.Contains("12345")?12345u:7767u),"state migration defaults only unset fertilizer");
    }
    File.WriteAllText(state,"broken input");type.GetField("stateReady",BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(instance,false);
    try{type.GetMethod("LoadState",BindingFlags.Instance|BindingFlags.NonPublic)!.Invoke(instance,null);throw new Exception("invalid state accepted");}catch(TargetInvocationException e)when(e.InnerException is System.IO.InvalidDataException){checks++;}
    persist.Invoke(instance,null);Check(File.ReadAllText(state)=="broken input","invalid original retained after startup failure");
    var collectible=new AssemblyLoadContext("KotiyaGarden-external-contract",true);
    collectible.Resolving+=(_,name)=>AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(a=>a.GetName().Name==name.Name);
    var external=collectible.LoadFromAssemblyPath(moduleFile).GetType(type.FullName!,true)!;
    var externalInstance=Activator.CreateInstance(external)!;
    var externalConfig=external.GetField("config",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(externalInstance)!;
    var serializer=type.BaseType!.Assembly.GetType("OmniToolbox.Config.CollectibleConfigJSON",true)!;
    serializer.GetMethod("Validate",BindingFlags.Static|BindingFlags.NonPublic,null,[typeof(object)],null)!.Invoke(null,[externalConfig]);
    Check(external.IsCollectible,"test follows actual external module load context");
    var layoutsField=externalConfig.GetType().GetField("Layouts")!;
    var presets=(IList)layoutsField.GetValue(externalConfig)!;
    var planner=external.Assembly.GetType("GardenLayout.GardenPlanner",true)!;
    var eight=planner.GetMethod("Create")!.Invoke(null,[8,null])!;presets.Add(eight);
    var cells=(IList)eight.GetType().GetProperty("Cells")!.GetValue(eight)!;
    cells[0]!.GetType().GetProperty("SeedId")!.SetValue(cells[0],8183u);
    var preferenceField=externalConfig.GetType().GetField("Preferences")!;var preference=preferenceField.GetValue(externalConfig)!;
    var houseModeProperty=preference.GetType().GetProperty("GroupByHouse")!;
    Check(!(bool)houseModeProperty.GetValue(preference)!,"old settings default to region grouping");houseModeProperty.SetValue(preference,true);
    var serialize=serializer.GetMethods(BindingFlags.Static|BindingFlags.NonPublic).Single(m=>m.Name=="Serialize");
    var json=serialize.Invoke(null,[externalConfig,null]);
    var restored=serializer.GetMethod("Deserialize",BindingFlags.Static|BindingFlags.NonPublic)!.Invoke(null,[json,externalConfig.GetType()]);
    Check(restored?.GetType()==externalConfig.GetType(),"actual host collectible settings serializer roundtrips module config");
    var restoredLayouts=(IList)layoutsField.GetValue(restored)!;
    var restoredCells=(IList)eight.GetType().GetProperty("Cells")!.GetValue(restoredLayouts[0])!;
    Check(restoredLayouts.Count==1&&restoredCells.Count==8,"actual host collectible serializer preserves eight layout cells");
    Check((uint)restoredCells[0]!.GetType().GetProperty("SeedId")!.GetValue(restoredCells[0])! ==8183u,"actual host collectible serializer preserves selected seed");
    var restoredPreference=preferenceField.GetValue(restored)!;
    Check((bool)houseModeProperty.GetValue(restoredPreference)!,"actual host collectible serializer retains house grouping preference");
    collectible.Unload();
    Console.WriteLine($"PASS: {checks} checks against the installed Omni Common/TreeTools DLLs; no game service or module lifecycle started.");
 }
}


