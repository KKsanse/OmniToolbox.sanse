using GardenLayout;
using Newtonsoft.Json;
using System.Text.Json;
static class LayoutRecoveryChecks
{
 public static int Run()
 {
    int checks=0;void Check(bool pass,string name){if(!pass)throw new Exception(name);checks++;}
    GardenPreset Make(int n){var p=GardenPlanner.Create(n);p.Name="圆葱试验";p.DefaultSoilId=9;for(int i=0;i<n;i++){p.Cells[i].SeedId=(uint)(i+1);p.Cells[i].SoilId=i==1?10u:0;}p.PlantOrder.Reverse();if(n==8)(p.Cells[0].NativeSlot,p.Cells[7].NativeSlot)=(7,0);return p;}
    GardenPreset Damage(GardenPreset p,int repeats){for(int i=0;i<repeats;i++){p.Cells.InsertRange(0,Enumerable.Range(0,8).Select(slot=>new GardenCell{NativeSlot=slot}));p.PlantOrder.InsertRange(0,Enumerable.Range(0,8));}return p;}
    foreach(int n in new[]{4,6,8}){
        var p=Make(n);string expected=System.Text.Json.JsonSerializer.Serialize(p);
        for(int round=0;round<8;round++){
            p=JsonConvert.DeserializeObject<GardenPreset>(JsonConvert.SerializeObject(p))!;
            Check(System.Text.Json.JsonSerializer.Serialize(p)==expected,"Newtonsoft config reload does not append defaults "+n+"/"+round);
        }
        p=System.Text.Json.JsonSerializer.Deserialize<GardenPreset>(expected)!;
        Check(System.Text.Json.JsonSerializer.Serialize(p)==expected,"System.Text.Json state roundtrip retains layout "+n);
        foreach(int repeats in new[]{1,2,4}){
            var damaged=Damage(Make(n),repeats);string id=damaged.Id;
            string content=System.Text.Json.JsonSerializer.Serialize(damaged);int backups=0;
            var report=GardenLayoutRecovery.Apply([damaged],()=>{Check(System.Text.Json.JsonSerializer.Serialize(damaged)==content,"backup occurs before mutation");backups++;});
            Check(report.Repaired==1&&report.Unresolved==0&&backups==1,"known default-prefix corruption recovered "+n+"/"+repeats);
            var good=Make(n);good.Id=id;
            Check(System.Text.Json.JsonSerializer.Serialize(damaged)==System.Text.Json.JsonSerializer.Serialize(good),"seeds soil calibration order name and id preserved "+n+"/"+repeats);
            Check(GardenLayoutRecovery.Apply([damaged],()=>throw new Exception("unexpected backup")).Repaired==0,"recovery idempotent");
            var code=GardenShare.Export(damaged);var imported=GardenShare.Import(code,[],Enumerable.Range(1,8).Select(i=>(uint)i).ToHashSet(),new HashSet<uint>{9,10});
            Check(imported.Cells.Count==n&&imported.PlantOrder.SequenceEqual(good.PlantOrder),"repaired layout exports and imports at real size "+n);
        }
    }
    var broken=Damage(Make(8),2);string before=System.Text.Json.JsonSerializer.Serialize(broken);
    try{GardenLayoutRecovery.Apply([broken],()=>throw new IOException("backup denied"));throw new Exception("backup error swallowed");}catch(IOException){checks++;}
    Check(System.Text.Json.JsonSerializer.Serialize(broken)==before,"failed backup cannot change any layout");
    var unknown=Damage(Make(8),1);unknown.Cells[0].SeedId=99;
    var reportBad=GardenLayoutRecovery.Apply([unknown],()=>throw new Exception("unsafe backup"));
    Check(reportBad.Unresolved==1&&reportBad.Repaired==0&&unknown.Cells.Count==16&&unknown.Cells[0].SeedId==99,"non-default extra seed data preserved rather than truncated");
    var orderOnly=Make(6);orderOnly.PlantOrder.InsertRange(0,Enumerable.Range(0,8));Check(GardenLayoutRecovery.Apply([orderOnly],()=>{}).Repaired==1&&orderOnly.Cells.Count==6,"order-only default-prefix damage repaired");
    var badOrder=Damage(Make(8),1);badOrder.PlantOrder[0]=7;Check(!GardenLayoutRecovery.TryRecover(badOrder,out _)&&badOrder.Cells.Count==16,"ambiguous order prevents partial repair");
    var empty=JsonConvert.DeserializeObject<GardenPreset>("{}")!;
    Check(empty.Cells.Count==0&&empty.PlantOrder.Count==0,"missing layout arrays are not invented as eight blank slots");
    string root=Path.Combine(Path.GetTempPath(),"garden-repair-test-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
    string file=Path.Combine(root,"state.json");File.WriteAllText(file,before);string backup=GardenLayoutRecovery.Backup(file);
    Check(File.ReadAllText(file)==before&&File.ReadAllText(backup)==before,"migration backup retains exact original bytes");
    File.WriteAllText(file,"new");Check(File.ReadAllText(backup)==before,"later saves cannot replace migration backup");
    // These are exclusively files created by this test, with fixed verified paths.
    File.Delete(file);File.Delete(backup);Directory.Delete(root);
    var mixedGood=Make(4);var mixedBad=Damage(Make(8),2);var reportMixed=GardenLayoutRecovery.Apply([mixedGood,mixedBad,unknown],()=>{});
    Check(reportMixed.Repaired==1&&reportMixed.Unresolved==1&&mixedGood.Cells.Count==4,"valid and unrecognized layouts left intact in mixed configuration");
    return checks;
 }
}
