using GardenLayout;

static class TalkChecks
{
 public static int Run()
 {
    int checks=0;void Check(bool value,string name){if(!value)throw new Exception(name);checks++;}
    Check(GardenTalkPolicy.CanAdvance(true,true,GardenAction.Care,true,true,true,false),"own active care dialog can advance");
    Check(!GardenTalkPolicy.CanAdvance(false,true,GardenAction.Care,true,true,true,false),"own dialog handling can be disabled");
    Check(!GardenTalkPolicy.CanAdvance(true,false,GardenAction.Care,true,true,true,false),"idle module never advances dialogs");
    foreach(var action in new[]{GardenAction.Plant,GardenAction.Fertilize,GardenAction.Harvest})Check(!GardenTalkPolicy.CanAdvance(true,true,action,true,true,true,false),"ordinary-talk helper cannot confirm planting/fertilizer/harvest");
    Check(!GardenTalkPolicy.CanAdvance(true,true,GardenAction.Care,false,true,true,false),"unselected care action cannot advance");
    Check(!GardenTalkPolicy.CanAdvance(true,true,GardenAction.Care,true,false,true,false),"changed target or house stops dialog handling");
    Check(!GardenTalkPolicy.CanAdvance(true,true,GardenAction.Care,true,true,false,false),"dialog already closed by another helper is ignored");
    Check(!GardenTalkPolicy.CanAdvance(true,true,GardenAction.Care,true,true,true,true),"same care step only advances once");
    Check(new GardenPreferences().AdvanceCareTalk,"standalone care progression enabled by default");
    Check(GardenText.Source.Count>250&&GardenText.Source.Values.All(x=>!string.IsNullOrWhiteSpace(x)),"complete module source catalog supplied");
    return checks;
 }
}
