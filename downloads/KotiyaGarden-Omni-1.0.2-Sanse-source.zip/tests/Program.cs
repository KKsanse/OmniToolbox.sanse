using GardenLayout;
using System.Text.Json;

static class Tests
{
 static int count;
 static void Check(bool ok,string name){if(!ok)throw new Exception(name);count++;}
 static void Reject(Action action,string name){try{action();}catch(ArgumentException){count++;return;}throw new Exception(name);}
 static GardenPreset Preset()=>new(){Name="A/B 杂交布局",DefaultSoilId=9,Cells=Enumerable.Range(0,8).Select(i=>new GardenCell{NativeSlot=i,SeedId=(uint)(i%2+1)}).ToList(),PlantOrder=Enumerable.Range(0,8).ToList()};
 static void Main()
 {
  var targets=Enumerable.Range(0,8).Reverse().Select(i=>GardenPlanner.Decode((ulong)(100+i),2003757,((uint)i<<24)|0x012212)).ToList();
  for(int i=0;i<8;i++){
   var decoded=GardenPlanner.Decode((ulong)(1073743235-i),2003757,((uint)i<<24)|0x012212);
   Check(decoded.NativeSlot==i&&decoded.GroupKey==0x012212,"observed native slot encoding");
  }
  Reject(()=>GardenPlanner.Decode(0,2003757,0x12212),"zero object id");
  Reject(()=>GardenPlanner.Decode(1,1,0x12212),"not garden object");
  Reject(()=>GardenPlanner.Decode(1,2003757,0x08012212),"out-of-range slot");
  Reject(()=>GardenPlanner.Decode(1,2003757,0),"missing garden group");
  var p=Preset();var plan=GardenPlanner.Plan(p,targets,0x012212,false);
  Check(plan.Select(s=>s.NativeSlot).SequenceEqual(Enumerable.Range(0,8)),"slot mapping independent of object-table order");
  Check(plan.Where((_,i)=>i%2==0).All(s=>s.SeedId==1)&&plan.Where((_,i)=>i%2==1).All(s=>s.SeedId==2),"per-cell seeds retained");
  Check(plan.All(s=>s.SoilId==9),"unified soil inherited");
  var stock=GardenPlanner.Materials(plan);Check(stock[1]==4&&stock[2]==4&&stock[9]==8,"materials aggregate maximum quantities");
  p.Cells[0].SoilId=10;plan=GardenPlanner.Plan(p,targets,0x012212,false);Check(plan[0].SoilId==10&&plan[1].SoilId==9,"cell soil override respected");
  p.Cells[0].SeedId=0;plan=GardenPlanner.Plan(p,targets,0x012212,false);Check(plan.Count==7&&plan.All(s=>s.NativeSlot!=0),"empty configured cell skipped");
  p=Preset();p.PlantOrder=new(){7,6,5,4,3,2,1,0};plan=GardenPlanner.Plan(p,targets,0x012212,false);
  Check(plan.Select(s=>s.NativeSlot).SequenceEqual(p.PlantOrder),"planting sequence preserved");
  p=Preset();(p.Cells[0].NativeSlot,p.Cells[7].NativeSlot)=(p.Cells[7].NativeSlot,p.Cells[0].NativeSlot);
  plan=GardenPlanner.Plan(p,targets,0x012212,false);Check(plan[0].NativeSlot==7&&plan[0].SeedId==1,"calibration remaps cell to game slot");
  var more=targets.Concat(Enumerable.Range(0,8).Select(i=>GardenPlanner.Decode((ulong)(200+i),2003757,((uint)i<<24)|0x002202))).ToList();
  plan=GardenPlanner.Plan(Preset(),more,0x012212,false);Check(plan.Count==8&&plan.All(s=>s.GroupKey==0x012212),"one group does not spill to neighboring garden");
  plan=GardenPlanner.Plan(Preset(),more,0,true);Check(plan.Count==16,"all-nearby planner covers groups once");
  var p2=Preset();p2.Cells.ForEach(c=>c.SeedId=88);
  var combined=GardenPlanner.Plan(Preset(),targets,0x012212,false).Concat(GardenPlanner.Plan(p2,more.Where(t=>t.GroupKey==0x002202).ToArray(),0x002202,false)).ToList();
  Check(combined.Where(s=>s.GroupKey==0x012212).All(s=>s.SeedId!=88)&&combined.Where(s=>s.GroupKey==0x002202).All(s=>s.SeedId==88),"different garden bindings keep distinct layouts");
  Reject(()=>GardenPlanner.Plan(Preset(),more,999,false),"missing selected group");
  Reject(()=>GardenPlanner.Plan(Preset(),targets.Take(7).ToArray(),0x012212,false),"partial garden rejected");
  Reject(()=>GardenPlanner.Plan(Preset(),targets.Concat(new[]{targets[0]}).ToArray(),0x012212,false),"duplicate slot rejected");
  var invalid=Preset();invalid.Cells[1].NativeSlot=0;Reject(()=>GardenPlanner.Validate(invalid),"duplicate calibration rejected");
  invalid=Preset();invalid.PlantOrder[0]=1;Reject(()=>GardenPlanner.Validate(invalid),"duplicate planting sequence rejected");
  invalid=Preset();invalid.DefaultSoilId=0;Reject(()=>GardenPlanner.Plan(invalid,targets,0x012212,false),"missing soil rejected");
  invalid=Preset();invalid.Cells.ForEach(c=>c.SeedId=0);Reject(()=>GardenPlanner.Plan(invalid,targets,0x012212,false),"no seeds rejected");
  invalid=Preset();invalid.Name="bad\nname";Reject(()=>GardenPlanner.Validate(invalid),"control characters rejected");
  invalid=Preset();invalid.Cells.RemoveAt(0);Reject(()=>GardenPlanner.Validate(invalid),"unsupported slot count rejected");
  var serialized=JsonSerializer.Serialize(p);var loaded=JsonSerializer.Deserialize<GardenPreset>(serialized)!;
  Check(loaded.Cells[0].NativeSlot==7&&loaded.Cells[0].SeedId==1&&loaded.PlantOrder.SequenceEqual(p.PlantOrder),"layout and calibration persist together");
  var binding=new GardenBinding{HouseId=1,GroupKey=0x012212,LayoutId=p.Id,X=10,Y=0,Z=10};
  Check(GardenPlanner.AnchorMatches(binding,10,0,10),"same anchor valid");
  Check(GardenPlanner.AnchorMatches(binding,10.3f,0,10),"small coordinate jitter valid");
  Check(!GardenPlanner.AnchorMatches(binding,11,0,10),"moved garden requires rebind");
  Check(!GardenPlanner.AnchorMatches(binding,float.NaN,0,10)&&!GardenPlanner.AnchorMatches(binding,float.PositiveInfinity,0,10),"invalid coordinates rejected");
  var b2=JsonSerializer.Deserialize<GardenBinding>(JsonSerializer.Serialize(binding))!;
  Check(b2.HouseId==1&&b2.GroupKey==binding.GroupKey&&b2.LayoutId==p.Id,"per-house per-garden binding persists");
  var named=new List<GardenPreset>{new(){Name="新布局"},new(){Name="新布局 (2)"}};
  Check(GardenPlanner.UniqueName("新布局",named)=="新布局 (3)","new layout names do not collide");
  string longName=new('长',64);named.Add(new(){Name=longName});
  string next=GardenPlanner.UniqueName(longName,named);
  Check(next.Length<=64&&next!=longName,"copy name remains valid at maximum length");
  int flowChecks=ExecutionChecks.Run();
  int recordChecks=RecordShareChecks.Run();
  int addressChecks=AddressNameChecks.Run(); int maintenanceChecks=MaintenanceSizeChecks.Run(); int identityChecks=CropIdentityChecks.Run(); int layoutChecks=LayoutRecoveryChecks.Run(); int catalogChecks=CatalogChecks.Run(); int groupingChecks=GroupingChecks.Run(); int talkChecks=TalkChecks.Run();
  Console.WriteLine($"PASS: {count+flowChecks+recordChecks+addressChecks+maintenanceChecks+identityChecks+layoutChecks+catalogChecks+groupingChecks+talkChecks} checks, including {addressChecks} address/name checks. No game actions or resource consumption.");
 }
}


