using GardenLayout;
using Newtonsoft.Json;
static class CatalogChecks
{
    sealed class SavedState { public Dictionary<string,string> Names {get;set;}=[];public Dictionary<string,List<int>> Slots {get;set;}=[];public List<GardenBinding> Bindings {get;set;}=[]; }
    public static int Run()
    {
        int count=0;void Check(bool value,string message){if(!value)throw new Exception(message);count++;}
        var state=new SavedState();var presets=new List<GardenPreset>{GardenPlanner.Create(8)};
        var records=new List<GardenRecord>{new(){HouseId=1,GroupKey=7,NativeSlot=0,SeedId=8183,CaredAt=DateTimeOffset.UtcNow}};
        foreach(int size in new[]{4,6,8}){
            ulong house=(ulong)size;uint group=7;
            var slots=Enumerable.Range(0,size).ToList();GardenCatalog.Remember(state.Names,state.Slots,house,group,slots,"未绑定试验田"+size);
            Check(state.Bindings.Count==0&&GardenCatalog.Saved(state.Names,state.Slots).Any(x=>x.HouseId==house&&x.GroupKey==group),"unbound discovered garden is saved "+size);
            slots.Clear();Check(state.Slots[GardenNames.Key(house,group)].Count==size,"saved slots are a snapshot "+size);
        }
        state=JsonConvert.DeserializeObject<SavedState>(JsonConvert.SerializeObject(state))!;
        Check(GardenCatalog.Saved(state.Names,state.Slots).Count==3&&state.Bindings.Count==0,"unbound gardens survive actual configuration serialization and restart");
        string renamed=GardenNames.Set(state.Names,8,7,"主屋花田");GardenCatalog.Remember(state.Names,state.Slots,8,7,Enumerable.Range(0,8),"园圃 1");
        Check(state.Names["8:7"]==renamed,"refresh cannot overwrite renamed garden");
        state.Bindings.Add(new(){HouseId=8,GroupKey=7,LayoutId=presets[0].Id});state.Bindings.Add(new(){HouseId=6,GroupKey=7,LayoutId=presets[0].Id});
        GardenCatalog.Forget(state.Names,state.Slots,state.Bindings,8,7);
        Check(!state.Names.ContainsKey("8:7")&&!state.Slots.ContainsKey("8:7")&&!state.Bindings.Any(b=>b.HouseId==8),"delete removes saved name slots and binding for selected garden");
        Check(state.Names.ContainsKey("6:7")&&state.Bindings.Single().HouseId==6,"same group in another house remains saved and bound");
        Check(presets.Count==1&&records.Count==1&&records[0].SeedId==8183&&records[0].CaredAt!=null,"delete retains planting preset and history");
        state=JsonConvert.DeserializeObject<SavedState>(JsonConvert.SerializeObject(state))!;
        Check(!GardenCatalog.Saved(state.Names,state.Slots).Any(b=>b.HouseId==8),"deleted entry stays deleted after restart");
        GardenCatalog.Remember(state.Names,state.Slots,8,7,Enumerable.Range(0,8),"重新发现的园圃");
        Check(GardenCatalog.Saved(state.Names,state.Slots).Any(b=>b.HouseId==8)&&!state.Bindings.Any(b=>b.HouseId==8),"explicit refresh can rediscover without automatic binding");
        var legacyNames=new Dictionary<string,string>();var legacySlots=new Dictionary<string,List<int>>();
        var legacyPreset=GardenPlanner.Create(6);var legacyBindings=new List<GardenBinding>{new(){HouseId=10,GroupKey=88,Name="旧版六格田",LayoutId=legacyPreset.Id}};
        GardenCatalog.RememberBindings(legacyNames,legacySlots,legacyBindings,[legacyPreset]);legacyBindings.Clear();
        Check(GardenCatalog.Saved(legacyNames,legacySlots).Single().Name=="旧版六格田"&&legacySlots["10:88"].Count==6,"old binding-only garden survives unbinding with its actual size");
        legacySlots["10:88"]=new(){0,2,4,6};legacyBindings.Add(new(){HouseId=10,GroupKey=88,NativeSlots=Enumerable.Range(0,8).ToList()});
        GardenCatalog.RememberBindings(legacyNames,legacySlots,legacyBindings,[]);
        Check(legacySlots["10:88"].SequenceEqual(new[]{0,2,4,6}),"newer discovered slot information is not overwritten by old binding");
        var oldNames=new Dictionary<string,string>();var oldSlots=new Dictionary<string,List<int>>{{"12:99",new(){0,2,4,6}},{"broken",new(){0,1,2,3}}};
        Check(GardenCatalog.Saved(oldNames,oldSlots).Single()==new GardenSavedEntry(12,99,""),"legacy unnamed unbound slot-only entry is visible without inventing a binding");
        string before=JsonConvert.SerializeObject(state);
        try{GardenCatalog.Remember(state.Names,state.Slots,0,7,new[]{0,1,2,3},"invalid");throw new Exception("invalid house accepted");}catch(ArgumentException){count++;}
        try{GardenCatalog.Remember(state.Names,state.Slots,8,7,new[]{0,1,1,3},"invalid");throw new Exception("duplicate slots accepted");}catch(ArgumentException){count++;}
        Check(JsonConvert.SerializeObject(state)==before,"invalid scan cannot corrupt stored catalog");
        var older=GardenPlanner.Create(8);for(int i=0;i<8;i++)older.Cells[i].SeedId=(uint)(i+10);
        var selected=GardenPlanner.Create(8);selected.Cells[0].SeedId=44;selected.Cells[1].SeedId=44;selected.Cells[2].SeedId=45;
        var candidates=GardenSeedClipboard.CandidateSeeds(selected,[older,selected]);
        Check(candidates.SequenceEqual(new uint[]{44,45,10,11}),"four unique candidate seeds prioritize active layout");
        Check(GardenSeedClipboard.CandidateSeeds(GardenPlanner.Create(8),[]).SequenceEqual(new uint[4]),"empty layouts keep four disabled candidate places");
        selected.Cells[3].SeedId=46;selected.Cells[4].SeedId=47;selected.Cells[5].SeedId=48;
        Check(GardenSeedClipboard.CandidateSeeds(selected,[older]).SequenceEqual(new uint[]{44,45,46,47}),"candidate list never grows beyond four");
        Check(GardenSeedClipboard.ConfiguredSeeds([older,selected]).Contains(48),"four candidate cap does not remove seeds from complete source list");
        var invalid=GardenPlanner.Create(4);invalid.Cells=null!;
        Check(GardenSeedClipboard.CandidateSeeds(selected,[invalid]).Length==4,"damaged unrelated layout cannot break candidate picker");
        return count;
    }
}
