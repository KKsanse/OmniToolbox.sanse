using GardenLayout;
using Newtonsoft.Json;
using System.Text.Json;
static class GroupingChecks
{
 public static int Run()
 {
    int count=0;void Check(bool value,string reason){if(!value)throw new Exception(reason);count++;}
    var beds=new List<GardenBedView>{
        new(11,7,"园圃 1",true,8,"海雾村","示例服 · 海雾村 1区1号"),new(11,8,"园圃 2",true,6,"海雾村","示例服 · 海雾村 1区1号"),
        new(22,7,"园圃 1",false,4,"海雾村","示例服 · 海雾村 1区2号"),new(33,7,"园圃 1",false,8,"白银乡","远方服 · 白银乡 5区18号")};
    var houses=GardenGrouping.Houses(beds);
    Check(houses.Count==3,"same region houses remain separate groups");
    Check(houses.Single(h=>h.HouseId==11).Beds.Select(b=>b.GroupKey).SequenceEqual(new uint[]{7,8}),"same house gardens are grouped together");
    Check(houses.Single(h=>h.HouseId==22).Beds.Count==1&&houses.Single(h=>h.HouseId==33).Label.Contains("远方服"),"ward plot world address retained");
    Check(GardenGrouping.Filter(beds,false,"海雾村",33).Count==3,"region mode ignores previous house filter");
    Check(GardenGrouping.Filter(beds,true,"海雾村",33).Single().HouseId==33,"house mode ignores previous region filter");
    Check(GardenGrouping.Filter(beds,false,"",22).Count==4&&GardenGrouping.Filter(beds,true,"白银乡",0).Count==4,"all-region and all-house options show all gardens");
    Check(GardenGrouping.Filter(beds,true,"",11).Count==2,"house selection shows every garden in selected house");
    Check(GardenGrouping.Filter(beds,true,"",999).Count==0,"unknown house never leaks other house gardens");
    Check(GardenGrouping.Houses([]).Count==0,"empty catalog groups safely");
    var unknown=new List<GardenBedView>{new(55,7,"园圃",false,8),new(66,7,"园圃",false,8)};
    Check(GardenGrouping.Houses(unknown).Select(h=>h.Label).Distinct().Count()==2,"missing addresses get distinct house labels");
    unknown[0]=unknown[0] with{Address="同名地址"};unknown[1]=unknown[1] with{Address="同名地址"};
    Check(GardenGrouping.Houses(unknown).Count==2&&GardenGrouping.Houses(unknown).Select(h=>h.Label).Distinct().Count()==2,"identity grouping cannot merge identical display addresses");
    Check(!new GardenPreferences().GroupByHouse&&!JsonConvert.DeserializeObject<GardenPreferences>("{}")!.GroupByHouse,"existing configs retain region mode by default");
    var preferences=new GardenPreferences{GroupByHouse=true};
    Check(JsonConvert.DeserializeObject<GardenPreferences>(JsonConvert.SerializeObject(preferences))!.GroupByHouse,"house mode persists in DR configuration");
    Check(System.Text.Json.JsonSerializer.Deserialize<GardenPreferences>(System.Text.Json.JsonSerializer.Serialize(preferences))!.GroupByHouse,"house mode persists in Omni state");
    return count;
 }
}
